# Raptorize for Rally

A Chrome extension to enable raptorize on any page and a few additions to integrate raptorize into certain Rally actions.

Chrome Extension available at:

https://chrome.google.com/webstore/detail/raptorize-for-rally/mkcefhphmjgojfnpdmajoceoekebapbb


Special thanks to:

Zurb Studios - for creating the initial jquery plugin

http://zurb.com/playground/jquery-raptorize

Alex Brovkin - for the work on the original chrome extension

http://brovalex.com/2015/01/26/raptorize-for-chrome/
